-- Optional Book Up cloud workspace table.
-- RLS is enabled and no permissive client policies are created by default.
-- Current client-side panel uses a Supabase anon key. Do NOT add unrestricted
-- anon SELECT/INSERT/UPDATE policies. Implement Supabase Auth + owner_id policies
-- or a trusted Edge Function before enabling production multi-device sync.

create table if not exists public.book_up_workspaces (
  id text primary key,
  slug text unique,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.book_up_workspaces enable row level security;
