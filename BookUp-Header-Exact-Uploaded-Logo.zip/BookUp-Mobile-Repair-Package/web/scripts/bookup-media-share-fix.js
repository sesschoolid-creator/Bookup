/* This source is inlined at the end of the Book Up document so it can use the
   existing profile/booking data while replacing the broken upload/share paths. */
(function () {
  'use strict';
  const byId = id => document.getElementById(id);
  const notify = message => {
    try { if (typeof toast === 'function') toast(message); else alert(message); }
    catch (_) { alert(message); }
  };
  const safeName = value => String(value || 'Book-Up').trim().replace(/[^a-z0-9_-]+/gi, '-').replace(/^-+|-+$/g, '') || 'Book-Up';

  async function imageAsDataUrl(file) {
    if (!file) throw new Error('No image was selected.');
    if (!/^image\//i.test(file.type || '')) throw new Error('Please select an image file (JPG, PNG or WEBP).');
    if (file.size > 25 * 1024 * 1024) throw new Error('This image is larger than 25 MB. Please choose a smaller image.');
    const source = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('The selected image could not be read.'));
      reader.onload = () => resolve(reader.result);
      reader.readAsDataURL(file);
    });
    const image = await new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('This image format could not be opened. Try JPG or PNG.'));
      img.src = source;
    });
    const max = 1600;
    const ratio = Math.min(1, max / Math.max(image.naturalWidth, image.naturalHeight));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(image.naturalWidth * ratio));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * ratio));
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Image processing is not available on this device.');
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    let data = canvas.toDataURL('image/jpeg', .78);
    if (data.length > 2_500_000) {
      const smaller = document.createElement('canvas');
      smaller.width = Math.max(1, Math.round(canvas.width * .7));
      smaller.height = Math.max(1, Math.round(canvas.height * .7));
      smaller.getContext('2d').drawImage(canvas, 0, 0, smaller.width, smaller.height);
      data = smaller.toDataURL('image/jpeg', .68);
    }
    return data;
  }

  // Android WebView can fail to open a display:none file input when it is nested
  // inside a label. Keep it visually transparent but physically clickable.
  const uploadStyle = document.createElement('style');
  uploadStyle.id = 'bu-android-file-input-fix';
  uploadStyle.textContent = `
    .bu-upload{position:relative!important;overflow:hidden!important;cursor:pointer!important;touch-action:manipulation}
    .bu-upload input[type=file]{display:block!important;position:absolute!important;inset:0!important;width:100%!important;height:100%!important;opacity:0!important;z-index:5!important;cursor:pointer!important;font-size:100px!important}
    .profile-upload-box input[type=file],.profile-owner-upload input[type=file],.profile-gallery-drop input[type=file],.profile-offer-image input[type=file]{display:block!important;position:absolute!important;inset:0!important;width:100%!important;height:100%!important;opacity:0!important;z-index:5!important;cursor:pointer!important}
    .bu-repeat-row input[type=file]{min-height:44px!important;cursor:pointer!important}
  `;
  document.head.appendChild(uploadStyle);

  // One delegated handler owns every relevant image upload. Capture phase stops
  // older duplicate listeners from overwriting or discarding the selected image.
  document.addEventListener('change', async event => {
    const input = event.target;
    if (!(input instanceof HTMLInputElement) || input.type !== 'file') return;
    const isProfile = input.matches('[data-profile-image]');
    const isCatalog = input.matches('[data-catalog-image]');
    const isLegacyOffer = input.matches('.oimage');
    if (!isProfile && !isCatalog && !isLegacyOffer) return;
    event.stopImmediatePropagation();
    event.stopPropagation();
    const file = input.files && input.files[0];
    if (!file) return;
    const previousLabel = input.closest('label');
    if (previousLabel) previousLabel.dataset.uploading = 'true';
    try {
      const data = await imageAsDataUrl(file);
      if (isProfile) {
        const key = input.dataset.profileImage;
        profile[key] = data;
        const thumb = byId('bu-thumb-' + key);
        if (thumb) { thumb.src = data; thumb.style.visibility = 'visible'; }
        if (typeof persist === 'function') persist();
        if (typeof renderLivePreview === 'function') renderLivePreview();
      } else if (isCatalog) {
        const kind = input.dataset.catalogImage;
        const index = Number(input.dataset.index);
        const list = kind === 'offers' ? offers : kind === 'services' ? (window.services || []) : products;
        if (!list || !list[index]) throw new Error('The selected product or offer row is no longer available. Please try again.');
        list[index].image = data;
        if (typeof persist === 'function') persist();
        if (typeof renderProductRows === 'function') renderProductRows();
        if (typeof renderLivePreview === 'function') renderLivePreview();
      } else {
        const row = input.closest('.offerblock');
        const index = Number(row && row.dataset.i);
        if (!Number.isInteger(index) || !offers[index]) throw new Error('The offer row could not be found. Please try again.');
        offers[index].image = data;
        if (typeof save === 'function') save('profile', profile);
        if (typeof renderOffers === 'function') renderOffers();
        if (typeof renderLivePreview === 'function') renderLivePreview();
      }
      notify('Image uploaded successfully.');
    } catch (error) {
      console.error('Book Up image upload:', error);
      notify('Image upload failed: ' + (error && error.message ? error.message : 'Please try another image.'));
    } finally {
      if (previousLabel) delete previousLabel.dataset.uploading;
      try { input.value = ''; } catch (_) {}
    }
  }, true);

  // Use the Capacitor share bridge in the installed Android app, Web Share API in
  // supported browsers, and a reliable download fallback elsewhere.
  async function shareFile(file, title, text) {
    if (window.BookUpNativeShare) {
      await window.BookUpNativeShare({ file, title, text });
      return 'shared';
    }
    if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({ title, text, files: [file] });
      return 'shared';
    }
    const url = URL.createObjectURL(file);
    const anchor = document.createElement('a');
    anchor.href = url; anchor.download = file.name || 'Book-Up-file';
    document.body.appendChild(anchor); anchor.click(); anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 15000);
    return 'downloaded';
  }
  window.bookUpShareFile = shareFile;

  function pdfText(value) {
    return String(value ?? '').replace(/₹/g, 'Rs. ').replace(/[–—]/g, '-').replace(/[•·]/g, '-').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^\x20-\x7E]/g, ' ');
  }
  function pdfEscape(value) { return pdfText(value).replace(/\\/g, '\\\\').replace(/\(/g, '\\(').replace(/\)/g, '\\)'); }
  function makeInvoicePdf(invoice, studio) {
    const W=595.28,H=841.89,ops=[];
    const palettes=window.bookUpPalettes||[];
    const theme=palettes.find(x=>x.id===(studio.theme||'ocean'))||palettes[0]||{accent:'#087e83',dark:'#123d46',bg:'#f2f8f8',surface:'#ffffff',text:'#173a45',muted:'#607c83',accent2:'#b9e4df'};
    const hex=h=>{const s=String(h||'#087e83').replace('#','');return [parseInt(s.slice(0,2),16)||0,parseInt(s.slice(2,4),16)||0,parseInt(s.slice(4,6),16)||0]};
    const rgb=c=>c.map(v=>(v/255).toFixed(4)).join(' ');
    const C={accent:hex(theme.accent),dark:hex(theme.dark),bg:hex(theme.bg),surface:hex(theme.surface),text:hex(theme.text),muted:hex(theme.muted),line:hex(theme.accent2),white:[255,255,255],soft:[248,250,251]};
    const fill=c=>ops.push(`${rgb(c)} rg`),stroke=c=>ops.push(`${rgb(c)} RG`);
    const rect=(x,t,w,h,c)=>{fill(c);ops.push(`${x.toFixed(2)} ${(H-t-h).toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re f`)};
    const line=(x1,t1,x2,t2,c=C.line,width=.7)=>{stroke(c);ops.push(`${width} w ${x1.toFixed(2)} ${(H-t1).toFixed(2)} m ${x2.toFixed(2)} ${(H-t2).toFixed(2)} l S`)};
    const txt=(v,x,t,size=9,bold=false,color=C.text,align='left')=>{const s=pdfText(v);fill(color);const tx=align==='right'?x-s.length*size*.51:align==='center'?x-s.length*size*.255:x;ops.push(`BT /${bold?'F2':'F1'} ${size} Tf 1 0 0 1 ${tx.toFixed(2)} ${(H-t-size).toFixed(2)} Tm (${pdfEscape(s)}) Tj ET`)};
    const wrap=(v,max)=>{const words=pdfText(v).split(/\s+/).filter(Boolean),out=[];let row='';for(const word of words){const n=row?row+' '+word:word;if(n.length>max&&row){out.push(row);row=word}else row=n}if(row)out.push(row);return out.length?out:['-']};
    const money=n=>'Rs. '+Number(n||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});
    const base=Math.max(0,Number(invoice.total)||0),tax=Math.max(0,Number(invoice.gstAmount)||0),grand=base+tax,paid=Math.max(0,Number(invoice.paid)||0),balance=Math.max(0,Number.isFinite(Number(invoice.balance))?Number(invoice.balance):grand-paid);
    const gstRate=Number(invoice.gstRate??(base&&tax?Math.round(tax/base*100):0));
    const studioName=studio.business||'Book Up Studio';
    const bookingList=window.bookings||bookings||[];
    const linkedBooking=bookingList.find(x=>String(x.id)===String(invoice.bookingId))||{};
    const functionRows=Array.isArray(invoice.functions)&&invoice.functions.length?invoice.functions:(Array.isArray(linkedBooking.functions)?linkedBooking.functions:[]);
    const photoRequirements=Array.isArray(invoice.requirements)?invoice.requirements:(Array.isArray(linkedBooking.requirements)?linkedBooking.requirements:[]);
    const outputItems=Array.isArray(invoice.outputs)?invoice.outputs:(Array.isArray(linkedBooking.outputs)?linkedBooking.outputs:[]);
    const projectNotes=String(invoice.notes||linkedBooking.notes||'').trim();
    // Premium full-width branded header using the profile's selected palette.
    rect(0,0,W,112,C.dark);rect(0,108,W,4,C.accent);
    txt(studioName,38,27,21,true,C.white);
    txt('INVOICE',557,23,23,true,C.white,'right');
    txt('STUDIO BILLING',557,52,8,true,C.line,'right');
    const address=[studio.address,studio.city,studio.state,studio.pin].filter(Boolean).join(', ');
    txt(address||'Studio address not provided',38,66,8,false,C.white);
    const studioContact=[studio.contact?'Contact: '+studio.contact:'',studio.whatsapp?'WhatsApp: '+studio.whatsapp:'',studio.email?'Email: '+studio.email:''].filter(Boolean).join('   |   ');
    txt(studioContact||'Book Up',38,84,7.5,false,C.line);
    // Invoice metadata and bill-to cards.
    const card=(x,y,w,h,label,value,sub='')=>{rect(x,y,w,h,C.soft);rect(x,y,3,h,C.accent);txt(label.toUpperCase(),x+12,y+9,6.8,true,C.muted);txt(value||'-',x+12,y+23,10,true,C.text);if(sub)txt(sub,x+12,y+39,7.2,false,C.muted)};
    card(38,128,252,59,'INVOICE NUMBER',invoice.number||'-','Date: '+new Date().toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}));
    card(302,128,255,59,'BILL TO',invoice.name||'Client',invoice.occasion||'Project / occasion not specified');
    txt('CLIENT GSTIN',38,201,6.5,true,C.muted);txt(invoice.gst||'Not provided',38,212,8.5,false,C.text);
    txt('STUDIO MEMBERSHIP ID',302,201,6.5,true,C.muted);txt(studio.membershipId||localStorage.getItem('bu_membership_id')||'BU-TMP-0001',302,212,8.5,false,C.text);
    line(38,232,557,232,C.line,.8);
    // Description and line-item table with fixed, readable columns.
    txt('ITEMIZED BILLING',38,246,9,true,C.accent);
    const tx=38,tw=519,hy=264,hh=25;
    rect(tx,hy,tw,hh,C.dark);
    txt('DESCRIPTION',tx+12,hy+8,7.3,true,C.white);
    txt('QTY',405,hy+8,7.3,true,C.white,'right');
    txt('RATE',475,hy+8,7.3,true,C.white,'right');
    txt('AMOUNT',tx+tw-12,hy+8,7.3,true,C.white,'right');
    const detail=String(invoice.details||'Photography / studio services').trim()||'Photography / studio services';
    const rowH=48;
    rect(tx,hy+hh,tw,rowH,C.surface);
    txt(invoice.occasion||'Studio services',tx+12,hy+hh+10,8.5,true,C.text);
    txt('Studio service package',tx+12,hy+hh+25,7,false,C.muted);
    txt('1',405,hy+hh+15,8,false,C.text,'right');
    txt(money(base),475,hy+hh+15,8,false,C.text,'right');
    txt(money(base),tx+tw-12,hy+hh+15,8,true,C.text,'right');
    line(tx,hy+hh+rowH,tx+tw,hy+hh+rowH,C.line,.8);
    // Structured event/function schedule and service scope, pulled from the linked booking.
    const scheduleY=360, scheduleX=38, scheduleW=519, scheduleHead=20, scheduleRow=17;
    txt('FUNCTION SCHEDULE',scheduleX,scheduleY-14,8.2,true,C.accent);
    rect(scheduleX,scheduleY,scheduleW,scheduleHead,C.dark);
    txt('FUNCTION / EVENT',scheduleX+10,scheduleY+6,7,true,C.white);
    txt('DATE',scheduleX+365,scheduleY+6,7,true,C.white,'right');
    txt('TIME',scheduleX+scheduleW-10,scheduleY+6,7,true,C.white,'right');
    let scheduleBottom=scheduleY+scheduleHead;
    const schedule=functionRows.length?functionRows:[{name:invoice.occasion||linkedBooking.occasion||'Function details not supplied',date:linkedBooking.date||'-',time:linkedBooking.time||'-'}];
    schedule.slice(0,3).forEach((f,i)=>{
      rect(scheduleX,scheduleBottom,scheduleW,scheduleRow,i%2?C.surface:C.soft);
      txt(f.name||'-',scheduleX+10,scheduleBottom+5,6.8,false,C.text);
      txt(f.date||'-',scheduleX+365,scheduleBottom+5,6.8,false,C.text,'right');
      txt(f.time||'-',scheduleX+scheduleW-10,scheduleBottom+5,6.8,false,C.text,'right');
      line(scheduleX,scheduleBottom+scheduleRow,scheduleX+scheduleW,scheduleBottom+scheduleRow,C.line,.45);
      scheduleBottom+=scheduleRow;
    });
    const scopeY=scheduleBottom+7, scopeH=54, scopeW=255;
    function scopePanel(title,items,x){
      rect(x,scopeY,scopeW,scopeH,C.soft);rect(x,scopeY,scopeW,18,C.bg);
      txt(title.toUpperCase(),x+9,scopeY+5,6.8,true,C.accent);
      const vals=items.length?items:['Not specified'];
      vals.slice(0,6).forEach((v,i)=>{const col=i%2,row=Math.floor(i/2);txt('- '+wrap(v,28)[0],x+9+col*124,scopeY+24+row*8.5,6.1,false,C.text)});
    }
    scopePanel('Photography requirements',photoRequirements,38);
    scopePanel('Deliverables / output',outputItems,302);
    if(projectNotes){
      const noteY=scopeY+scopeH+3;rect(38,noteY,519,11,C.surface);
      txt('NOTES: '+wrap(projectNotes,130)[0],45,noteY+2,5.8,false,C.muted);
    }
    let y=510;
    // Totals panel, aligned to right and visually emphasized.
    const sx=302,sw=255,sh=31;
    txt('AMOUNT SUMMARY',sx,y,8.5,true,C.accent);y+=15;
    const totalRows=[['Subtotal',money(base)],['GST ('+gstRate+'%)',money(tax)],['Invoice total',money(grand)],['Payments received',money(paid)]];
    totalRows.forEach((r,i)=>{if(i===2)rect(sx,y-3,sw,sh,C.bg);txt(r[0],sx+10,y+6,i===2?8.5:8,i===2,C.text);txt(r[1],sx+sw-10,y+6,i===2?8.5:8,i===2,C.text,'right');line(sx,y+sh-2,sx+sw,y+sh-2,C.line,.5);y+=sh});
    rect(sx,y,sw,37,C.dark);txt('BALANCE DUE',sx+10,y+12,9,true,C.white);txt(money(balance),sx+sw-10,y+10,12,true,C.white,'right');
    // Payment history table occupies the left half of the page.
    let py=510;
    txt('PAYMENT HISTORY',38,py,8.5,true,C.accent);py+=16;
    rect(38,py,246,21,C.bg);txt('#',46,py+7,6.8,true,C.muted);txt('DATE / TIME',68,py+7,6.8,true,C.muted);txt('RECEIVED',276,py+7,6.8,true,C.muted,'right');py+=21;
    const payments=Array.isArray(invoice.payments)?invoice.payments:[];
    if(!payments.length){txt('No payments recorded',46,py+8,7.2,false,C.muted);py+=24}
    else payments.slice(0,6).forEach((p,i)=>{if(i%2===0)rect(38,py,246,22,C.soft);txt(String(i+1),46,py+7,7,false,C.text);txt((p.at||p.date||'Payment').slice(0,25),68,py+7,6.6,false,C.text);txt(money(p.amount),276,py+7,6.8,true,C.text,'right');py+=22});
    // Sign-off and footer use remaining page space without clipping.
    const footerY=720;
    line(38,footerY,557,footerY,C.line,1);
    txt('CLIENT ACKNOWLEDGEMENT',38,footerY+15,7,true,C.muted);
    line(38,footerY+57,235,footerY+57,C.muted,.6);
    txt('CLIENT SIGNATURE',38,footerY+62,6.5,false,C.muted);
    txt('FOR '+pdfText(studioName).toUpperCase(),350,footerY+15,7,true,C.muted);
    line(350,footerY+57,557,footerY+57,C.muted,.6);
    txt('AUTHORIZED SIGNATURE',350,footerY+62,6.5,false,C.muted);
    txt('Thank you for choosing '+studioName+'.',W/2,827,8,true,C.accent,'center');
    const content=ops.join('\n'),enc=new TextEncoder();
    const objects=['<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Kids [3 0 R] /Count 1 >>',`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>`,'<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>','<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>'];
    const stream=enc.encode(content);objects.push({prefix:`<< /Length ${stream.length} >>\nstream\n`,data:stream,suffix:'\nendstream'});
    const chunks=[enc.encode('%PDF-1.4\n')],offsets=[0];let pos=chunks[0].length;
    objects.forEach((o,i)=>{offsets.push(pos);const h=enc.encode(`${i+1} 0 obj\n`);chunks.push(h);pos+=h.length;if(typeof o==='string'){const b=enc.encode(o);chunks.push(b);pos+=b.length}else{const a=enc.encode(o.prefix);chunks.push(a);pos+=a.length;chunks.push(o.data);pos+=o.data.length;const z=enc.encode(o.suffix);chunks.push(z);pos+=z.length}const e=enc.encode('\nendobj\n');chunks.push(e);pos+=e.length});
    const xrefPos=pos;let xref=`xref\n0 ${objects.length+1}\n0000000000 65535 f \n`;for(let i=1;i<offsets.length;i++)xref+=String(offsets[i]).padStart(10,'0')+' 00000 n \n';
    chunks.push(enc.encode(xref+`trailer\n<< /Size ${objects.length+1} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF`));
    const size=chunks.reduce((n,b)=>n+b.length,0),out=new Uint8Array(size);let at=0;chunks.forEach(b=>{out.set(b,at);at+=b.length});return out;
  }

  window.shareInvoice = async function (id) {
    const invoice = (window.invoices || invoices || []).find(item => String(item.id) === String(id));
    if (!invoice) { notify('Invoice not found. Please refresh the invoice directory.'); return; }
    try {
      const bytes = makeInvoicePdf(invoice, profile || {});
      const file = new File([bytes], `${safeName(profile.business)}-Invoice-${safeName(invoice.number || invoice.name)}.pdf`, { type: 'application/pdf' });
      const result = await shareFile(file, 'Book Up Invoice', `Invoice ${invoice.number || ''} for ${invoice.name || 'client'}. Total ${pdfText(Number(invoice.total || 0) + Number(invoice.gstAmount || 0))}.`);
      if (result === 'downloaded') notify('Invoice PDF downloaded. Use your phone share menu to send it on WhatsApp or another app.');
    } catch (error) {
      if (error && error.name === 'AbortError') return;
      console.error('Book Up invoice share:', error); notify('Invoice PDF could not be shared: ' + (error.message || 'Please try again.'));
    }
  };

  // Profile HTML is shared as a file; it is not represented as a fake public URL.
  window.shareProfileFile = async function () {
    try {
      if (typeof ensureSections === 'function') ensureSections();
      const html = typeof buildProfileHtml === 'function' ? buildProfileHtml() : '';
      if (!html) throw new Error('The profile preview is not ready. Open See Profile and try again.');
      const file = new File([html], safeName(profile.business) + '.html', { type: 'text/html' });
      const result = await shareFile(file, profile.business || 'Business Profile', 'Business profile website from Book Up.');
      if (result === 'downloaded') notify('Profile HTML downloaded. Share the downloaded file from your phone.');
    } catch (error) {
      if (error && error.name === 'AbortError') return;
      console.error('Book Up profile share:', error); notify('Profile could not be shared: ' + (error.message || 'Please try again.'));
    }
  };
})();
