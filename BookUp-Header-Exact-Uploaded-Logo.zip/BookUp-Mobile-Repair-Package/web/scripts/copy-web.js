const fs = require('fs');
const path = require('path');
const web = path.join(__dirname, '..', 'www');
if (!fs.existsSync(path.join(web, 'index.html'))) {
  console.error('Missing www/index.html');
  process.exit(1);
}
console.log('Book Up web assets ready for Capacitor sync.');
