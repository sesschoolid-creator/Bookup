#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Node.js 20+ and npm are required." >&2; exit 1
fi
npm install
if [ ! -d android ]; then
  npx cap add android
fi
npm run android:sync
if [ ! -x android/gradlew ]; then
  echo "Capacitor Android project was not generated. Check Android SDK / Gradle setup." >&2; exit 1
fi
(cd android && ./gradlew assembleDebug)
mkdir -p ../build-output
cp android/app/build/outputs/apk/debug/app-debug.apk ../build-output/BookUp-debug-updated.apk
echo "Created: $(pwd)/../build-output/BookUp-debug-updated.apk"
echo "This is a debug-signed APK. For an update over an existing Play/release installation, sign with the original release keystore."
