BOOK UP V10 + V8 CATALOGUE — SHARED PROFILE BLANK PAGE FIX

This update fixes the exported/shared profile HTML document for Android/WhatsApp content:// viewing.

Changes:
- Normalizes malformed escaped closing script tags in generated profile HTML so Android Chrome can finish parsing the page.
- Adds a final export integrity check for complete HTML/body/profile markup before sharing.
- Forces the exported profile container and sections to remain visible and naturally scrollable, including in social in-app browsers.
- Preserves the existing V10 landing design, membership ID, product/offer details and Book Now sliding requirement drawer.
- Updates the service-worker cache key so installed copies can load the repaired files.

After installing this update, open See Profile and share a newly generated profile HTML file. Previously shared HTML files remain unchanged.

Validation: JavaScript syntax checks and ZIP integrity checks are performed on this package. Live WhatsApp/Android device testing is not available in this environment.


LATEST UPDATE — MOBILE HERO BUTTONS + KNOW MORE FIX

- Mobile profile landing page now stacks Call, WhatsApp and Explore our work vertically, one button per row. Desktop keeps the three buttons on one horizontal line.
- Fixed exported/shared HTML Know More handling with a single delegated click handler for both Products Gallery and Offers.
- Removed conflicting duplicate Know More click handlers that could prevent the detail view from opening consistently.
- Product and offer detail panels open the full detail view; Book Now opens the booking requirement form and sends the item, membership ID and customer details to the business WhatsApp.
- Added address to the shared booking form to match the live profile booking flow.

Validation: all inline JavaScript blocks passed Node syntax checks; service-worker syntax and ZIP integrity are checked in the delivered package. Live WhatsApp/Android testing was not available.


Latest patch: Shared HTML Know More buttons in OUR COLLECTION and LIMITED TIME / SPECIAL now use one delegated handler and open the same product/offer detail panel with Book Now and the requirement form. Generate and share a fresh profile after installing this update.
