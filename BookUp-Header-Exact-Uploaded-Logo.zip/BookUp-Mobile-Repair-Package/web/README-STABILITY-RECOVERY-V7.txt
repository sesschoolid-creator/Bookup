BOOK UP — STABILITY RECOVERY + BUSINESS PROFILE FIX (V7)

WHAT THIS UPDATE DOES
- Restores the clean Book Up web app source from the pre-V4/V5/V6 profile patch build. This removes the accumulated profile patch scripts that were inserted into the main HTML and could break script parsing and page execution.
- Keeps the existing Book Up pages, admin panel, learning area, AI editor, bookings, finance, and other existing modules from the clean source package.
- Loads the business-profile repair as a separate JavaScript file (profile-stability.js), rather than injecting additional script blocks into the large index.html.
- Shows filled profile sections and hides empty Portfolio, Products, Services, Offers, and Opening Hours sections.
- Shows one Offers & Packages section. Each offer has a Know more button that opens a separate tab with the saved offer information and a Book Now form.
- Shows icon-only circular contact/social buttons in Let’s Connect.
- Shows one Share It and one Save Contact button pair at the very end of the profile.
- Applies the same offer details, booking, share and contact-export behavior to the generated standalone HTML profile.
- Compresses offer images before saving them to browser storage to reduce storage pressure and preserve multiple offer images.
- Bumps the service-worker cache and pre-caches profile-stability.js.

INSTALLATION — WEB HOSTING
1. Back up the current website files.
2. Extract this ZIP.
3. Upload/replace the complete www folder contents, including index.html, sw.js, manifest.webmanifest, icons, and profile-stability.js.
4. Ensure profile-stability.js is uploaded beside index.html in the www folder.
5. Clear the old browser/site cache or close and reopen the app, then generate a fresh business profile.

INSTALLATION — ANDROID / CAPACITOR
1. Replace the project www folder with the included www folder.
2. Run: npm install
3. Run: npm run android:sync
4. Open Android Studio with: npm run android:open
5. Build and sign a fresh APK/AAB in Android Studio.

IMPORTANT
- Previously exported profile HTML files do not update automatically. Generate and share a new profile after installing this update.
- HTML-file sharing support depends on the receiving social app. If the share sheet cannot accept an HTML file, Share It downloads the HTML file so it can be attached manually.
- Offer booking submission opens WhatsApp using the business WhatsApp/contact number. It does not silently send or store enquiries on a remote server.
- This package passed inline JavaScript syntax checks, external script syntax checks, and ZIP integrity checks. A live Android device test has not been performed.
