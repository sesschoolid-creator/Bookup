BOOK UP — FULL SOURCE + ANDROID WRAPPER PACKAGE
================================================

INCLUDED
- www/index.html: latest Book Up v9 source. The Admin Panel is embedded in this file.
- www/sw.js and www/manifest.webmanifest: PWA shell.
- www/icons/: generated 192px and 512px icons (replace with official Book Up logo if available).
- Capacitor Android wrapper configuration and package.json, including native Filesystem + Share plugins for real PDF/HTML sharing.
- admin-integration/: optional Supabase table schema and security guidance.
- PLAY-STORE-CHECKLIST.txt and PRIVACY-POLICY-TEMPLATE.txt.

ADMIN / DATA
The Admin Panel is already included in index.html; it is not a separate server app.
Several app settings, uploads and records are stored in browser/device local storage.
They do not automatically sync between devices. The optional cloud panel supports a
Supabase endpoint, but production multi-user access must use authentication and
owner-scoped RLS or a trusted Edge Function. Never place a Supabase service_role key
or any private secret in client-side HTML.

BUILD
Requirements: Node.js 20+, Android Studio, compatible JDK, Android SDK Platform 36.
From this folder run:
  npm install
  npx cap add android
  npm run android:sync
  npm run android:open

In Android Studio choose Build > Generate Signed Bundle / APK > Android App Bundle.
Create your own upload keystore and keep secure backups. Never share the keystore.

APP ID
Currently set to com.bookup.app. Verify that it is unique before first publication.
Change capacitor.config.ts before running `npx cap add android` if required.

IMPORTANT
This is a complete web source + Android wrapper setup package, NOT a signed APK/AAB.
A signed Android binary cannot be generated here without Android SDK/build tools,
your signing key and a tested build environment. Test on real Android devices before
Play Store submission, especially camera/photo picker, downloads, sharing, external
links, offline mode and all admin workflows.


MEDIA UPLOAD + PDF / PROFILE SHARING REPAIR
- The business logo, owner photo, product image and offer image inputs now use a WebView-safe transparent overlay rather than display:none. A single delegated image handler validates, compresses, saves and previews selected images with visible error messages.
- Android builds bundle scripts/native-share.js with esbuild. The bridge writes generated PDFs/HTML into the app cache and opens the Android native share sheet through @capacitor/share.
- Booking quotation PDFs use the native share bridge when running in the Capacitor app, then Web Share API in supported browsers.
- Invoice Share now creates a real A4 PDF file and opens the same native/browser share flow. View / PDF remains the print action.
- After editing source, run npm install and npm run android:sync, then rebuild/reinstall the Android app. This package is source, not a signed APK.

INVOICE / QUOTATION PDF UPDATE
The current source uses the selected profile theme for a full-page A4 invoice PDF. Quotation enquiry PDFs use simple text contact details without call/WhatsApp pictograms or the studio logo. Rebuild with npm run android:sync and generate a signed APK in Android Studio.

INVOICE / QUOTATION PDF UPDATE
The current source uses the selected profile theme for a full-page A4 invoice PDF. Quotation enquiry PDFs use simple text contact details without call/WhatsApp pictograms or the studio logo. Rebuild with npm run android:sync and generate a signed APK in Android Studio.
